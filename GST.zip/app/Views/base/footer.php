
<!-- Footer -->	  
	  
<footer class="bg_dark_blue pt-5 pb-5">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2">
				<a href="#">Contact us</a>
			</div>

			<div class="col-md-1">
				<a href="#"> Phone</a>
			</div>


			<div class="col-md-1">

			</div>


			<div class="col-md-1">
				<a href="#">Services</a>
			</div>

		
			<div class="col-md-2">
				<ul class="footer_link p-0 m-0">
					<li> <a href="#">Contact us</a> </li>
					<li> <a href="#">Ordering & Payment</a> </li>
					<li> <a href="#">Shipping</a> </li>
					<li> <a href="#">partners</a> </li>
					<li> <a href="#">FAQ</a> </li>
					<li> <a href="#">Blog</a> </li>
					
				</ul>
			</div>
			
			<div class="col-md-2">
			</div>	
			
			<div class="col-md-3">
				<ul class="social_links p-0 m-0">
					<li><a href="javascript:void(0)" class="fa fa-instagram"></a></li>
					<li><a href="javascript:void(0)" class="fa fa-twitter"></a></li>
					<li><a href="javascript:void(0)" class="fa fa-facebook"></a></li>
				</ul>
			</div>
		</div>
	</div>
</footer>	  
	  
	  
    <!-- Optional JavaScript -->

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
